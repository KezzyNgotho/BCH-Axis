import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';

import walletRoutes from './wallet';
import vaultRoutes from './vault';
import multiVaultRoutes from './multisigVault';
import escrowRoutes from './escrow';
import feeRoutes from './fees';
import kycRoutes from './kyc';
import paymentRoutes from './payment';
import contractsRoutes from './contracts';
import txRoutes from './tx';

const app = express();
app.use(cors());
app.use(bodyParser.json());

app.use('/api/wallet', walletRoutes);
app.use('/api/vault', vaultRoutes);
app.use('/api/multisig-vault', multiVaultRoutes);
app.use('/api/escrow', escrowRoutes);
app.use('/api/fees', feeRoutes);
app.use('/api/kyc', kycRoutes);
app.use('/api/payment', paymentRoutes);
app.use('/api/contracts', contractsRoutes);
app.use('/api/tx', txRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`BCH Axis backend running on port ${PORT}`));
