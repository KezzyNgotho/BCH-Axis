import express from 'express';
import cors from 'cors';
import morgan from 'morgan';

import vaultRoutes from './api/vault.js';
import paymentRoutes from './api/payment.js';
import escrowRoutes from './api/escrow.js';
import feesRoutes from './api/fees.js';
import walletRoutes from './api/wallet.js';
import kycRoutes from './api/kyc.js';

const app = express();

app.use(cors());
app.use(express.json());
app.use(morgan('dev'));

// API routes
app.use('/api/vault', vaultRoutes);
app.use('/api/payment', paymentRoutes);
app.use('/api/escrow', escrowRoutes);
app.use('/api/fees', feesRoutes);
app.use('/api/wallet', walletRoutes);
app.use('/api/kyc', kycRoutes);

// health check
app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

export default app;
