interface Fee {
  id: string;
  name: string;
  rate: number; // percentage
}

const fees: Fee[] = [
  { id: 'platform', name: 'Platform Fee', rate: 0.5 },
  { id: 'transaction', name: 'Transaction Fee', rate: 0.2 },
];

export const getFees = () => fees;

export const calculateFee = (amount: number, feeId: string) => {
  const fee = fees.find(f => f.id === feeId);
  if (!fee) throw new Error('Fee type not found');
  return (amount * fee.rate) / 100;
};
