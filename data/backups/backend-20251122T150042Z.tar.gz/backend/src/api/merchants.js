import { Router } from 'express';
import crypto from 'crypto';
import db from '../db.js';

const router = Router();

function hmacKey(key) {
  const secret = process.env.API_KEY_SECRET || null;
  if (!secret) {
    // For dev fallback, use sha256 of static string to avoid throwing here
    return crypto.createHmac('sha256', crypto.createHash('sha256').update('dev-secret').digest('hex')).update(key).digest('hex');
  }
  return crypto.createHmac('sha256', secret).update(key).digest('hex');
}

// Create merchant and return api key (plaintext returned once)
router.post('/', (req, res) => {
  const { name, xpub, scopes } = req.body;
  if (!name) return res.status(400).json({ error: 'Name required' });
  const id = crypto.randomUUID();
  const api_key = crypto.randomBytes(32).toString('hex');
  const api_key_hash = hmacKey(api_key);
  const now = new Date().toISOString();
  db.prepare('INSERT INTO merchants (id, name, api_key, api_key_hash, xpub, next_index, scopes, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
    .run(id, name, null, api_key_hash, xpub || null, 0, scopes || null, now);
  // Return plaintext api_key only at creation time so the merchant can store it
  res.json({ id, name, api_key, xpub: xpub || null });
});

// Prepare on-chain registration payload (OP_RETURN hex and instructions)
router.post('/prepare-registration', (req, res) => {
  const { name, xpub } = req.body;
  if (!name || !xpub) return res.status(400).json({ error: 'name and xpub required' });
  const payload = { type: 'merchant-reg', name, xpub, ts: Date.now() };
  const payloadStr = JSON.stringify(payload);
  const opReturnHex = Buffer.from(payloadStr, 'utf8').toString('hex');

  const instructions = `This prepares an OP_RETURN payload that you must include in a small BCH transaction from your own wallet. The server does not sign or broadcast for you — you keep your private keys offline. Steps:\n\n1) Use your wallet or CLI to create a transaction that includes an OP_RETURN output containing the following hex payload:\n\n${opReturnHex}\n\n2) Broadcast the transaction to the BCH network (testnet/mainnet as appropriate).\n\n3) After the transaction is confirmed, the registry entry will be discoverable on-chain. You can then use the on-chain registry to prove ownership and derive addresses from your xpub.\n\nIf you need a code snippet, see the returned examples (bch-js snippet and a generic curl broadcast example).`;

  const example_bchjs = `// bch-js example (node)
const BCHJS = require('@psf/bitcoincashjs-lib'); // replace with proper bch-js import
// Build a txn with an OP_RETURN output containing hex: ${opReturnHex}
// Use your wallet to add inputs and sign the transaction before broadcasting.`;

  const example_blockbook = `// Example: broadcast raw tx via Blockbook
POST ${process.env.BLOCKBOOK_URL || 'https://BLOCKBOOK_URL'}/api/v2/sendtx/ with { rawtx: '<signed-raw-hex>' }`;

  res.json({ op_return_hex: opReturnHex, op_return_string: payloadStr, instructions, example_bchjs, example_blockbook });
});

// Claim registration: merchant posts txid of their registration transaction; server validates and issues short-lived token
router.post('/claim-registration', async (req, res) => {
  const { txid } = req.body;
  if (!txid) return res.status(400).json({ error: 'txid required' });
  try {
    const registry = await import('../service/registry.js');
    const entry = await registry.claimRegistration(txid);
    // return token to merchant
    res.json({ token: entry.token, xpub: entry.xpub, name: entry.name, expiresAt: entry.expiresAt });
  } catch (e) {
    res.status(400).json({ error: e && e.message ? e.message : String(e) });
  }
});

// Lookup merchant by xpub in in-memory registry
router.get('/by-xpub/:xpub', (req, res) => {
  const { xpub } = req.params;
  try {
    const registry = require('../service/registry.js').default;
    const entry = registry.getByXpub(xpub);
    if (!entry) return res.status(404).json({ error: 'Not found' });
    res.json(entry);
  } catch (e) {
    res.status(500).json({ error: e && e.message ? e.message : String(e) });
  }
});

// List merchants (no api key returned)
router.get('/', (req, res) => {
  const rows = db.prepare('SELECT id, name, created_at, xpub, scopes, revoked FROM merchants').all();
  res.json(rows);
});

// Rotate API key (authenticated)
router.post('/:id/rotate-key', (req, res) => {
  const key = req.header('x-api-key');
  if (!key) return res.status(401).json({ error: 'Missing API key' });
  const row = db.prepare('SELECT * FROM merchants WHERE id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Merchant not found' });
  // Only allow rotating when authenticated as this merchant
  // validate provided key matches this merchant
  const providedHash = hmacKey(key);
  const ownsKey = (row.api_key && row.api_key === key) || (row.api_key_hash && row.api_key_hash === providedHash);
  if (!ownsKey) return res.status(403).json({ error: 'Not authorized' });

  const newKey = crypto.randomBytes(32).toString('hex');
  const newHash = hmacKey(newKey);
  db.prepare('UPDATE merchants SET api_key = NULL, api_key_hash = ?, revoked = 0 WHERE id = ?').run(newHash, req.params.id);
  res.json({ id: row.id, api_key: newKey });
});

// Revoke API key (authenticated)
router.delete('/:id/revoke', (req, res) => {
  const key = req.header('x-api-key');
  if (!key) return res.status(401).json({ error: 'Missing API key' });
  const row = db.prepare('SELECT * FROM merchants WHERE id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Merchant not found' });
  const providedHash = hmacKey(key);
  const ownsKey = (row.api_key && row.api_key === key) || (row.api_key_hash && row.api_key_hash === providedHash);
  if (!ownsKey) return res.status(403).json({ error: 'Not authorized' });

  db.prepare('UPDATE merchants SET revoked = 1, api_key = NULL WHERE id = ?').run(req.params.id);
  res.json({ id: row.id, revoked: true });
});

export default router;
