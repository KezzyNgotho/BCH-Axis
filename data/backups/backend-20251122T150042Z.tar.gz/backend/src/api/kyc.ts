import { Router } from 'express';
import { registerBusiness, verifyBusiness, listBusinesses } from '../service/kycService';

const router = Router();

router.post('/register', (req, res) => {
  const { name } = req.body;
  try {
    const business = registerBusiness(name);
    res.json(business);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.post('/verify', (req, res) => {
  const { businessId } = req.body;
  try {
    const business = verifyBusiness(businessId);
    res.json(business);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.get('/', (req, res) => {
  res.json(listBusinesses());
});

export default router;
