export interface BusinessKYC {
  businessId: string;
  name: string;
  verified: boolean;
  documents?: string[];
}

const businesses: BusinessKYC[] = [];

export const registerBusiness = (name: string): BusinessKYC => {
  const business: BusinessKYC = {
    businessId: crypto.randomUUID(),
    name,
    verified: false,
  };
  businesses.push(business);
  return business;
};

export const verifyBusiness = (businessId: string): BusinessKYC => {
  const business = businesses.find(b => b.businessId === businessId);
  if (!business) throw new Error('Business not found');
  business.verified = true;
  return business;
};

export const listBusinesses = () => businesses;
