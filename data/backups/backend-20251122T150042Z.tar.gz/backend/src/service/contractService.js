// Minimal contract service stub for dev. Replace with real contract loader in production.
export default {
  loadContracts: () => ({
    Vault: { address: null, privateKey: null, artifact: null },
    MultiSigVault: { address: null, privateKey: null, artifact: null }
  }),
  getContract: (name) => {
    const c = { Vault: { artifact: null }, MultiSigVault: { artifact: null } };
    return c[name] || null;
  }
};
