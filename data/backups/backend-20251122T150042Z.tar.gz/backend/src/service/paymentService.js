import crypto from 'crypto';
import db from '../db.js';
import bip32 from 'bip32';
import * as bitcoin from 'bitcoinjs-lib';
import bchaddr from 'bchaddrjs';

export function createInvoice({ buyer, amount, currency = 'BCH', vaultId = null, webhookUrl = null, merchantId = null }) {
  const id = crypto.randomUUID();
  const now = new Date().toISOString();

  // If merchantId not provided, attempt to read it from the vault record
  let mId = merchantId;
  if (!mId && vaultId) {
    const v = db.prepare('SELECT merchant_id FROM vaults WHERE id = ?').get(vaultId);
    if (v && v.merchant_id) mId = v.merchant_id;
  }

  const stmt = db.prepare(`INSERT INTO invoices (id, buyer, amount, currency, vault_id, merchant_id, webhook_url, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`);
  stmt.run(id, buyer, amount, currency, vaultId, mId, webhookUrl, 'pending', now);

  // Attempt deterministic address derivation if merchant has xpub
  try {
    if (mId) {
      const merchant = db.prepare('SELECT * FROM merchants WHERE id = ?').get(mId);
      if (merchant && merchant.xpub) {
        // use merchant.next_index as child index (atomic increment)
        const nextIdxRow = db.prepare('SELECT next_index FROM merchants WHERE id = ?').get(mId);
        let idx = 0;
        if (nextIdxRow && typeof nextIdxRow.next_index !== 'undefined') idx = Number(nextIdxRow.next_index || 0);

        // derive address
        const node = bip32.fromBase58(merchant.xpub);
        const child = node.derive(idx);
        const pubkey = child.publicKey;
        const legacy = bitcoin.payments.p2pkh({ pubkey, network: bitcoin.networks.testnet }).address;
        const cashAddr = bchaddr.toCashAddress(legacy);

        // update invoice with derived address
        db.prepare('UPDATE invoices SET address = ? WHERE id = ?').run(cashAddr, id);

        // increment merchant next_index
        db.prepare('UPDATE merchants SET next_index = next_index + 1 WHERE id = ?').run(mId);
      }
    }
  } catch (e) {
    console.warn('Failed to derive invoice address', e && e.message ? e.message : e);
  }

  return getInvoice(id);
}

export function listInvoices() {
  const rows = db.prepare('SELECT * FROM invoices ORDER BY created_at DESC').all();
  return rows;
}

export function getInvoice(id) {
  const row = db.prepare('SELECT * FROM invoices WHERE id = ?').get(id);
  return row || null;
}

export async function markInvoicePaid(id, txid = null) {
  const inv = getInvoice(id);
  if (!inv) throw new Error('Invoice not found');
  const paidAt = new Date().toISOString();
  db.prepare('UPDATE invoices SET status = ?, txid = ?, paid_at = ? WHERE id = ?').run('paid', txid, paidAt, id);

  const updated = getInvoice(id);
  if (updated.webhook_url) {
    try {
      // Use global fetch (Node 18+) to POST webhook
      await fetch(updated.webhook_url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ invoiceId: updated.id, status: updated.status, txid: updated.txid, amount: updated.amount })
      });
    } catch (err) {
      console.warn('Failed to deliver webhook for invoice', updated.id, err && err.message ? err.message : err);
    }
  }

  return updated;
}

export function findPendingInvoicesForVault(vaultId) {
  return db.prepare('SELECT * FROM invoices WHERE vault_id = ? AND status = ?').all(vaultId, 'pending');
}
