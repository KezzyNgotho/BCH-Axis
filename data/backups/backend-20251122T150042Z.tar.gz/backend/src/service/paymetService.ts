interface Invoice {
  id: string;
  recipient: string;
  amount: number;
  status: 'pending' | 'paid';
}

const invoices: Invoice[] = [];

export const createInvoice = async ({ recipient, amount }: { recipient: string, amount: number }): Promise<Invoice> => {
  const invoice = { id: crypto.randomUUID(), recipient, amount, status: 'pending' };
  invoices.push(invoice);
  return invoice;
};

export const getInvoiceStatus = async (id: string): Promise<Invoice> => {
  const invoice = invoices.find(inv => inv.id === id);
  if (!invoice) throw new Error('Invoice not found');
  return invoice;
};

export const markInvoicePaid = async (id: string): Promise<Invoice> => {
  const invoice = invoices.find(inv => inv.id === id);
  if (!invoice) throw new Error('Invoice not found');
  invoice.status = 'paid';
  return invoice;
};
