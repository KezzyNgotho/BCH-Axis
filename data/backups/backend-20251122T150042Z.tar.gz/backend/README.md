# Backend Contract Integration

This README describes how the backend discovers compiled CashScript artifacts and deployed contract addresses and how to interact with them.

Endpoints added:

- `GET /api/contracts` - returns discovered contracts (from `deployment.json` or `build/*.json`).
- `GET /api/contracts/:name` - returns a single contract entry (includes `address`, `artifact`, `txid` if available).
- `GET /api/vault/:id/utxos` - returns UTXOs for a vault's assigned address.
- `POST /api/tx/broadcast` - body `{ "rawTxHex": "..." }` to broadcast a signed raw transaction via BCH full node.

Notes:
- Server-side signing is intentionally not fully implemented for arbitrary CashScript contracts because building unlocking scripts is contract-specific and requires careful testing.
- `deploy.mjs` writes `deployment.json` with derived addresses and private keys; `contractService` will attach private keys to discovered contracts (if present). Use caution storing private keys in files.

Recommended next steps:
- Implement a `contractRunner` that instantiates `cashscript.Contract` objects (requires mapping constructor args and provider).
- Implement safe server-side signing for specific contracts (e.g. `Vault`) with tests, or prefer client-side signing and use `/api/tx/broadcast` to publish signed txs.

