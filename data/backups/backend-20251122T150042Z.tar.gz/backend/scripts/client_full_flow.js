#!/usr/bin/env node
/*
Full client-side flow demo (best-effort):
- Reads prepared payload (via local prepare function or deployment/build)
- Attempts to instantiate CashScript Contract and build a signed tx using provided private key
- If successful, posts rawTxHex to backend `/api/tx/broadcast`

Usage:
  node backend/scripts/client_full_flow.js [vaultName] [recipient] [amountSats] [privkeyWIF] [apiUrl]

Notes:
- Requires `cashscript` and `@psf/bch-js` installed in the environment where you run this script.
- This script is a convenience demo and not production-ready. Keep private keys secure.
*/

const fs = require('fs');
const path = require('path');
const axios = require('axios');

async function loadPrepare(vaultName) {
  const deploymentPath = path.resolve(process.cwd(), 'deployment.json');
  const buildDir = path.resolve(process.cwd(), 'build');
  let deployment = null;
  if (fs.existsSync(deploymentPath)) {
    try { deployment = JSON.parse(fs.readFileSync(deploymentPath, 'utf8')); } catch (e) {}
  }
  let entry = null;
  if (deployment && deployment.contracts && deployment.contracts[vaultName]) entry = deployment.contracts[vaultName];
  else {
    const file = path.join(buildDir, `${vaultName}.json`);
    if (fs.existsSync(file)) entry = { name: vaultName, artifact: JSON.parse(fs.readFileSync(file, 'utf8')), address: null };
  }
  if (!entry) throw new Error('Contract artifact not found for ' + vaultName);

  // Attempt to fetch utxos with bch-js if available
  let utxos = [];
  try {
    const BCH = require('@psf/bch-js');
    const bchjs = new BCH({ restURL: process.env.BCH_REST_URL || 'https://trest.bitcoin.com/v2/' });
    if (entry.address) {
      const r = await bchjs.Address.utxo(entry.address);
      utxos = r && r.utxos ? r.utxos : r;
    }
  } catch (err) {
    // ignore
  }

  return { entry, utxos };
}

async function attemptCashScript(artifact, address, utxos, recipient, amountSats, privkeyWIF) {
  try {
    const cs = require('cashscript');
    const { Contract, ElectrumNetworkProvider } = cs;
    const electrumUrl = process.env.ELECTRUM_URL || null;
    let provider = null;
    try { if (electrumUrl) provider = new ElectrumNetworkProvider(electrumUrl); } catch (e) { provider = null; }

    let contract;
    try {
      contract = provider && address ? new Contract(artifact, address, provider) : new Contract(artifact);
    } catch (err) {
      return { ok: false, reason: 'instantiate-failed', error: err };
    }

    if (!contract.functions || !contract.functions.spend) return { ok: false, reason: 'no-spend' };

    const fn = contract.functions.spend;
    const call = fn(amountSats);

    // Try common builder methods
    if (call.createTransaction) {
      const txObj = await call.createTransaction({ utxos, to: recipient, changeAddress: address });
      if (txObj && txObj.hex) return { ok: true, rawTxHex: txObj.hex };
    }

    if (call.toTransaction) {
      const tx = await call.toTransaction({ utxos, to: recipient, changeAddress: address });
      if (tx && tx.toHex) return { ok: true, rawTxHex: tx.toHex() };
      if (tx && tx.hex) return { ok: true, rawTxHex: tx.hex };
    }

    if (call.create) {
      try { const tx = await call.create({ utxos, to: recipient, changeAddress: address }); if (tx && tx.hex) return { ok: true, rawTxHex: tx.hex }; } catch (e) {}
    }

    if (call.send) {
      try {
        // Some versions broadcast automatically; we try with broadcast:false
        const res = await call.send({ broadcast: false });
        if (res && res.rawTxHex) return { ok: true, rawTxHex: res.rawTxHex };
        if (res && res.tx && res.tx.hex) return { ok: true, rawTxHex: res.tx.hex };
      } catch (e) {
        // ignore
      }
    }

    return { ok: false, reason: 'no-api-produced-raw-hex' };
  } catch (err) {
    return { ok: false, reason: 'require-failed', error: err };
  }
}

async function broadcastRawHex(apiUrl, rawHex) {
  try {
    const url = (apiUrl || 'http://localhost:3000') + '/api/tx/broadcast';
    const res = await axios.post(url, { rawTxHex: rawHex });
    return res.data;
  } catch (err) {
    throw err;
  }
}

async function main() {
  const args = process.argv.slice(2);
  const vaultName = args[0] || 'Vault';
  const recipient = args[1] || 'bchtest:qqexample...';
  const amountSats = args[2] ? parseInt(args[2], 10) : 10000;
  const privkeyWIF = args[3] || null;
  const apiUrl = args[4] || 'http://localhost:3000';

  console.log('Full client flow for', vaultName, recipient, amountSats);

  const { entry, utxos } = await loadPrepare(vaultName);
  console.log('Artifact:', entry.artifact ? entry.artifact.contractName : 'none');
  console.log('Address:', entry.address);
  console.log('UTXOs:', (utxos && utxos.length) || 0);

  const res = await attemptCashScript(entry.artifact, entry.address, utxos, recipient, amountSats, privkeyWIF);
  if (!res.ok) {
    console.error('CashScript attempt failed:', res.reason || res.error);
    console.log('\nIf CashScript is not installed, run in backend folder:');
    console.log('  cd backend && npm install');
    console.log('\nOr run the frontend example to construct & sign the transaction using CashScript.');
    process.exit(1);
  }

  console.log('Raw tx hex produced:');
  console.log(res.rawTxHex);

  // Try broadcasting using backend
  try {
    const br = await broadcastRawHex(apiUrl, res.rawTxHex);
    console.log('Broadcast response:', br);
  } catch (err) {
    console.error('Broadcast failed:', err && err.response ? err.response.data : err.message || err);
    process.exit(1);
  }
}

main().catch(err => { console.error('Fatal:', err && err.message ? err.message : err); process.exit(1); });
