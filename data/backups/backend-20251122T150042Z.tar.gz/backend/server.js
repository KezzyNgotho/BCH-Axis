// Entrypoint shim: delegate to `src/index.js` which contains the real app.
// This keeps `node server.js` working from the repo root while the source
// lives in `src/` (ESM modules / TypeScript sources).
import fs from 'fs';
import path from 'path';

const built = path.resolve(process.cwd(), 'build', 'index.js');
const srcEntry = path.resolve(process.cwd(), 'src', 'index.js');

(async () => {
	try {
		// Prefer running the `src` entry during development to avoid partially-built `build/` artifacts.
		if (fs.existsSync(srcEntry)) {
			await import(`file://${srcEntry}`);
		} else if (fs.existsSync(built)) {
			await import(`file://${built}`);
		} else {
			throw new Error('No entrypoint found (src/index.js or build/index.js)');
		}
	} catch (err) {
		console.error('Failed to start backend', err && err.stack ? err.stack : err);
		process.exit(1);
	}
})();
