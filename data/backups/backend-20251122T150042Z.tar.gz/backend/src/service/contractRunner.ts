import contractService from './contractService';
import path from 'path';
import { Contract, ElectrumNetworkProvider } from 'cashscript';

/**
 * Contract runner: exposes loaded contract metadata and (optionally)
 * instantiated `cashscript.Contract` objects when given an Electrum provider URL.
 *
 * This module is defensive: if cashscript can't instantiate a Contract (missing
 * address, provider issues, etc.) it will still return metadata so other
 * services can operate.
 */

export function listContracts() {
  return contractService.loadContracts();
}

export function getContract(name: string) {
  return contractService.getContract(name);
}

/**
 * Instantiate Contract objects for all discovered contracts.
 * @param electrumUrl optional Electrum server URL (or provider) to create provider
 * @returns map of name -> { info, instance? }
 */
export function loadInstances(electrumUrl?: string) {
  const infos = contractService.loadContracts();
  const out: Record<string, any> = {};

  let provider: any = undefined;
  if (electrumUrl || process.env.ELECTRUM_URL) {
    const url = electrumUrl || process.env.ELECTRUM_URL;
    try {
      provider = new ElectrumNetworkProvider(url);
    } catch (err) {
      // If provider construction fails, continue without provider.
      provider = undefined;
    }
  }

  for (const [name, info] of Object.entries(infos)) {
    out[name] = { info };
    try {
      if (provider && info && info.artifact && info.address) {
        // Try to instantiate a cashscript.Contract with (artifact, address, provider)
        try {
          const c = new Contract(info.artifact, info.address, provider);
          out[name].instance = c;
        } catch (err) {
          // Fallback: try (artifact, provider)
          try {
            const c = new Contract(info.artifact, provider);
            out[name].instance = c;
          } catch (err2) {
            // give up; leave instance undefined
          }
        }
      }
    } catch (err) {
      // ignore per-contract errors
    }
  }

  return out;
}

export default { listContracts, getContract, loadInstances };
