import express from 'express';
import cors from 'cors';
import walletRoutes from './api/wallet.js';
import vaultRoutes from './api/vault.js';
import paymentRoutes from './api/payment.js';
import txRoutes from './api/tx.js';
import merchantRoutes from './api/merchants.js';

const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/wallet', walletRoutes);
app.use('/api/vault', vaultRoutes);
app.use('/api/payment', paymentRoutes);
app.use('/api/tx', txRoutes);
app.use('/api/merchants', merchantRoutes);

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => console.log(`BCH Axis API running on port ${PORT}`));
