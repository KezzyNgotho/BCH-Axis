import { bch } from '../config/bchClient.js';
import * as vaultService from './vaultService.js';
import * as paymentService from './paymentService.js';

let pollingInterval = 20000; // 20s
let running = false;
let lastRun = null;

export function startUtxoWatcher(intervalMs = 20000) {
  if (running) return;
  pollingInterval = intervalMs;
  running = true;
  runOnce();
  setInterval(runOnce, pollingInterval);
}

export function getStatus() {
  return { running, pollingInterval, lastRun };
}

async function runOnce() {
  lastRun = new Date();
  try {
    const vaults = vaultService.listVaults();
    for (const v of vaults) {
      try {
        // Check pending invoices for this vault; each invoice may have a dedicated address
        const pending = paymentService.findPendingInvoicesForVault(v.id);
        if (pending && pending.length) {
          for (const inv of pending) {
            const addressToCheck = inv.address || v.address;
            if (!addressToCheck) continue;
            try {
              const utxoRes = await bch.Address.utxo(addressToCheck);
              const utxos = utxoRes && utxoRes.utxos ? utxoRes.utxos : utxoRes;
              const addrSats = (utxos || []).reduce((s, u) => s + (u.satoshis || u.value || 0), 0);
              if (addrSats >= inv.amount) {
                const txid = (utxos && utxos[0] && (utxos[0].tx_hash || utxos[0].txid)) ? (utxos[0].tx_hash || utxos[0].txid) : null;
                await paymentService.markInvoicePaid(inv.id, txid);
              }
            } catch (err) {
              console.warn('Error fetching utxos for invoice address', addressToCheck, err && err.message ? err.message : err);
            }
          }
        }
      } catch (err) {
        console.warn('Error processing vault', v.id, err && err.message ? err.message : err);
      }
    }
  } catch (err) {
    console.error('Utxo watcher run error', err && err.message ? err.message : err);
  }
}
