import { Router } from 'express';
import { bch } from '../config/bchClient';

const router = Router();

// POST /api/tx/broadcast  { rawTxHex }
router.post('/broadcast', async (req, res) => {
  try {
    const { rawTxHex } = req.body;
    if (!rawTxHex) return res.status(400).json({ error: 'rawTxHex required' });

    // Use bch-js to broadcast raw transaction hex
    const result = await bch.RawTransactions.sendRawTransaction([rawTxHex]);
    // bch-js returns array of txids
    res.json({ result });
  } catch (err: any) {
    res.status(500).json({ error: err.message || String(err) });
  }
});

export default router;
