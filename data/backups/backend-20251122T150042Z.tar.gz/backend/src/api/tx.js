import { Router } from 'express';
import { requireApiKey } from '../middleware/auth.js';
import { broadcastRawTransaction } from '../config/bchClient.js';

const router = Router();

// Broadcast a signed raw transaction (hex) to the network.
// Body: { rawTxHex }
router.post('/broadcast', requireApiKey, async (req, res) => {
  const { rawTxHex } = req.body;
  if (!rawTxHex) return res.status(400).json({ error: 'rawTxHex required' });
  try {
    const txid = await broadcastRawTransaction(rawTxHex);
    res.json({ txid });
  } catch (err) {
    res.status(500).json({ error: err && err.message ? err.message : String(err) });
  }
});

export default router;
