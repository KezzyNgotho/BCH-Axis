#!/usr/bin/env node
// Local demo: prepare payload for client-side signing for the first Vault found in deployment.json
// Usage: node backend/scripts/prepare_local_demo.js [vaultName|'Vault'] [recipient] [amountSats]

const fs = require('fs');
const path = require('path');

async function main() {
  const args = process.argv.slice(2);
  const vaultName = args[0] || 'Vault';
  const recipient = args[1] || 'bchtest:qqexample...';
  const amountSats = args[2] ? parseInt(args[2], 10) : 10000;

  const deploymentPath = path.resolve(process.cwd(), 'deployment.json');
  const buildDir = path.resolve(process.cwd(), 'build');

  let deployment = null;
  if (fs.existsSync(deploymentPath)) {
    try {
      deployment = JSON.parse(fs.readFileSync(deploymentPath, 'utf8'));
    } catch (err) {
      console.error('Failed to parse deployment.json:', err.message);
    }
  }

  let contractEntry = null;
  if (deployment && deployment.contracts && deployment.contracts[vaultName]) {
    contractEntry = deployment.contracts[vaultName];
  } else {
    // fallback: load build/<vaultName>.json
    const file = path.join(buildDir, `${vaultName}.json`);
    if (fs.existsSync(file)) {
      try {
        const artifact = JSON.parse(fs.readFileSync(file, 'utf8'));
        contractEntry = { name: vaultName, artifact, address: null };
      } catch (err) {
        console.error('Failed to parse artifact:', err.message);
        process.exit(1);
      }
    }
  }

  if (!contractEntry) {
    console.error('No contract entry found for', vaultName);
    process.exit(1);
  }

  const artifact = contractEntry.artifact || null;
  const address = contractEntry.address || null;

  // Try to get utxos using bch-js if available
  let utxos = [];
  try {
    const BCH = require('@psf/bch-js');
    const bchjs = new BCH({ restURL: process.env.BCH_REST_URL || 'https://trest.bitcoin.com/v2/' });
    if (address) {
      const r = await bchjs.Address.utxo(address);
      utxos = r && r.utxos ? r.utxos : r;
    } else {
      utxos = [];
    }
  } catch (err) {
    // Not fatal; just warn
    console.warn('Warning: could not fetch UTXOs (network may be down or @psf/bch-js missing):', err.message || err);
    utxos = [];
  }

  const payload = {
    vault: {
      name: contractEntry.name || vaultName,
      address: address,
    },
    artifact,
    abi: artifact ? artifact.abi : null,
    utxos,
    suggestedInputIndex: 0,
    to: recipient,
    amountSats,
    note: 'This payload mirrors the /api/vault/:id/prepare response for client-side signing.'
  };

  console.log(JSON.stringify(payload, null, 2));
}

main().catch(err => {
  console.error('Fatal:', err.message || err);
  process.exit(1);
});
