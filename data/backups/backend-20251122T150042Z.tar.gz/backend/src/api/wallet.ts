import { Router } from 'express';
import { Wallet, createWallet, getWallet } from '../services/walletService';

const router = Router();

// Create a new wallet
router.post('/create', (req, res) => {
  const wallet = createWallet();
  res.json(wallet);
});

// Get wallet info
router.get('/:address', (req, res) => {
  try {
    const wallet = getWallet(req.params.address);
    res.json(wallet);
  } catch (err: any) {
    res.status(404).json({ error: err.message });
  }
});

// List all wallets
router.get('/', (req, res) => {
  res.json(Wallet.list());
});

export default router;
