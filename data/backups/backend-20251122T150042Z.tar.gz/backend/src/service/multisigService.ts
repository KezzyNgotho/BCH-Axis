import { bch } from '../config/bchClient';
import fs from 'fs';
import path from 'path';
import { Vault } from './vaultService';
import CashScript from '@cashscript/cashscript'; // ensure proper import

const compiled = JSON.parse(
  fs.readFileSync(path.join(__dirname, '../contracts/compiled-json/MultiSigVault.json'), 'utf8')
);

export interface MultiSigVault extends Vault {
  requiredSignatures: number;
  owners: string[];
}

const multiVaults: MultiSigVault[] = [];

export const createMultiSigVault = async (
  owners: string[],
  requiredSignatures: number
): Promise<MultiSigVault> => {
  if (requiredSignatures > owners.length)
    throw new Error('Required signatures cannot exceed owners count');

  const vault: MultiSigVault = {
    id: crypto.randomUUID(),
    name: `MultiVault-${multiVaults.length + 1}`,
    type: 'multi',
    owners,
    requiredSignatures,
    balance: 0
  };

  multiVaults.push(vault);
  return vault;
};

export const spendMultiSigVault = async (
  vaultId: string,
  recipient: string,
  amount: number,
  signatures: string[]
) => {
  const vault = multiVaults.find((v) => v.id === vaultId);
  if (!vault) throw new Error('Vault not found');
  if (signatures.length < vault.requiredSignatures)
    throw new Error('Insufficient signatures');

  if (amount > vault.balance) throw new Error('Insufficient balance');

  vault.balance -= amount;
  return { success: true, recipient, amount };
};

export const listMultiVaults = () => multiVaults;
