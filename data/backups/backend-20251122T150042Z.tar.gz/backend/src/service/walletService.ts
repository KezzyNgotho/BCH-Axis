import { bch } from '../config/bchClient';
import crypto from 'crypto';

export interface Wallet {
  address: string;
  wif: string;
  balance: number;
}

export const createWallet = (): Wallet => {
  const mnemonic = bch.Mnemonic.generate();
  const rootSeed = bch.Mnemonic.toSeed(mnemonic);
  const hdNode = bch.HDNode.fromSeed(rootSeed, 'testnet');
  const keyPair = hdNode.derivePath("m/44'/145'/0'/0/0");
  const address = bch.HDNode.toCashAddress(keyPair);
  return { address, wif: keyPair.toWIF(), balance: 0 };
};

export const getWalletBalance = async (address: string): Promise<number> => {
  const result = await bch.Blockbook.balance(address);
  return result.balance;
};
