import { Router } from 'express';

const router = Router();

// Minimal wallet stub for dev: implement later or replace with TS implementation
router.get('/', (req, res) => {
  res.json({ message: 'Wallet API stub - not implemented in dev shim' });
});

export default router;
