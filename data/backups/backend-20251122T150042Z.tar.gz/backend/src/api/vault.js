import { Router } from 'express';
import { createVault, listVaults, spendVault, getVaultUtxos, getVault, prepareVaultSpend } from '../service/vaultService.js';
import { getStatus as utxoWatcherStatus } from '../service/utxoWatcher.js';

const router = Router();

// Create a single-sig vault
import { requireApiKey } from '../middleware/auth.js';

router.post('/create', requireApiKey, async (req, res) => {
  const { owner, type } = req.body;
  try {
    const merchantId = req.merchant && req.merchant.id ? req.merchant.id : null;
    const vault = await createVault(owner, type, merchantId);
    res.json(vault);
  } catch (err) {
    res.status(400).json({ error: err && err.message ? err.message : String(err) });
  }
});

// Spend from vault
router.post('/spend', async (req, res) => {
  const { vaultId, recipient, amount } = req.body;
  try {
    const result = await spendVault(vaultId, recipient, amount);
    res.json(result);
  } catch (err) {
    res.status(400).json({ error: err && err.message ? err.message : String(err) });
  }
});

// Prepare unsigned spend payload for client-side signing
router.post('/:id/prepare', requireApiKey, async (req, res) => {
  const { id } = req.params;
  const { recipient, amount } = req.body;
  try {
    const payload = await prepareVaultSpend(id, recipient, amount);
    res.json(payload);
  } catch (err) {
    res.status(400).json({ error: err && err.message ? err.message : String(err) });
  }
});

router.get('/:id/utxos', async (req, res) => {
  try {
    const utxos = await getVaultUtxos(req.params.id);
    res.json(utxos);
  } catch (err) {
    res.status(400).json({ error: err && err.message ? err.message : String(err) });
  }
});

router.get('/:id', (req, res) => {
  const v = getVault(req.params.id);
  if (!v) return res.status(404).json({ error: 'Vault not found' });
  res.json(v);
});

// List all vaults
router.get('/', (req, res) => {
  res.json(listVaults());
});

export default router;

// Admin endpoint for watcher status
router.get('/admin/utxo-watcher', (req, res) => {
  try {
    res.json(utxoWatcherStatus());
  } catch (err) {
    res.status(500).json({ error: err && err.message ? err.message : String(err) });
  }
});
