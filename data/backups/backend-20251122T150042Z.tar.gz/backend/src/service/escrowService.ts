import crypto from 'crypto';

export interface Escrow {
  id: string;
  buyer: string;
  seller: string;
  amount: number;
  status: 'pending' | 'released' | 'cancelled';
}

const escrows: Escrow[] = [];

export const createEscrow = (buyer: string, seller: string, amount: number): Escrow => {
  const escrow: Escrow = {
    id: crypto.randomUUID(),
    buyer,
    seller,
    amount,
    status: 'pending',
  };
  escrows.push(escrow);
  return escrow;
};

export const releaseEscrow = (escrowId: string) => {
  const escrow = escrows.find((e) => e.id === escrowId);
  if (!escrow) throw new Error('Escrow not found');
  escrow.status = 'released';
  return escrow;
};

export const cancelEscrow = (escrowId: string) => {
  const escrow = escrows.find((e) => e.id === escrowId);
  if (!escrow) throw new Error('Escrow not found');
  escrow.status = 'cancelled';
  return escrow;
};

export const listEscrows = () => escrows;
