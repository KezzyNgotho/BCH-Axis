import crypto from 'crypto';

// In-memory registry: no external DB. Entries are short-lived tokens mapping to on-chain registration.
const STORE = new Map(); // token -> entry
const XPUB_INDEX = new Map(); // xpub -> token

const DEFAULT_TTL = Number(process.env.REGISTRY_TOKEN_TTL_SEC || 60 * 60 * 24); // 24h

async function fetchTx(txid) {
  const blockbook = process.env.BLOCKBOOK_URL;
  if (!blockbook) throw new Error('BLOCKBOOK_URL not configured');
  const url = blockbook.replace(/\/$/, '') + '/api/v2/tx/' + txid;
  // use global fetch (Node 18+) if available
  const _fetch = (typeof fetch !== 'undefined') ? fetch : globalThis.fetch;
  if (!_fetch) throw new Error('No fetch available in runtime');
  const resp = await _fetch(url);
  if (!resp.ok) throw new Error('Failed to fetch tx ' + resp.status);
  return resp.json();
}

function parseOpReturnFromTx(tx) {
  // Blockbook represents vout[].scriptPubKey.hex or asm; OP_RETURN script usually in vout[i].scriptPubKey.hex
  for (const v of tx.vout || []) {
    if (!v.scriptPubKey || !v.scriptPubKey.hex) continue;
    const hex = v.scriptPubKey.hex;
    // OP_RETURN scripts often start with 6a (OP_RETURN)
    if (hex.startsWith('6a')) {
      // Strip the leading OP_RETURN opcode and any pushdata opcodes. For simplicity, extract trailing data bytes.
      // A robust parser is outside the scope; assume format '6a' + push + data
      // Find the first non-push-data byte sequence: look for ascii JSON inside
      try {
        // naive: convert entire hex to utf8 and try JSON.parse
        const buf = Buffer.from(hex, 'hex');
        // remove leading 0x6a and any small length bytes
        let start = 1;
        while (start < buf.length && buf[start] <= 0x4b) start++;
        const data = buf.slice(start).toString('utf8');
        const jsonStart = data.indexOf('{');
        const jsonEnd = data.lastIndexOf('}');
        if (jsonStart !== -1 && jsonEnd !== -1 && jsonEnd > jsonStart) {
          const jsonStr = data.slice(jsonStart, jsonEnd + 1);
          return jsonStr;
        }
      } catch (e) {
        continue;
      }
    }
  }
  return null;
}

export async function claimRegistration(txid) {
  if (!txid) throw new Error('txid required');
  const tx = await fetchTx(txid);
  const jsonStr = parseOpReturnFromTx(tx);
  if (!jsonStr) throw new Error('No OP_RETURN JSON payload found in tx');
  let payload;
  try { payload = JSON.parse(jsonStr); } catch (e) { throw new Error('Invalid OP_RETURN JSON'); }
  if (!payload || !payload.xpub || !payload.name) throw new Error('Payload missing xpub/name');

  // create token
  const token = crypto.randomBytes(24).toString('hex');
  const now = Date.now();
  const entry = { token, txid, xpub: payload.xpub, name: payload.name, meta: payload.meta || null, createdAt: now, expiresAt: now + DEFAULT_TTL * 1000 };
  STORE.set(token, entry);
  XPUB_INDEX.set(payload.xpub, token);
  return entry;
}

export function getByToken(token) {
  const e = STORE.get(token);
  if (!e) return null;
  if (Date.now() > e.expiresAt) {
    STORE.delete(token);
    XPUB_INDEX.delete(e.xpub);
    return null;
  }
  return e;
}

export function getByXpub(xpub) {
  const token = XPUB_INDEX.get(xpub);
  if (!token) return null;
  return getByToken(token);
}

export default { claimRegistration, getByToken, getByXpub };
