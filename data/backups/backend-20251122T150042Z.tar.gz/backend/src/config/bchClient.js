// Minimal stub bch client for development. Replace with real bch-js client in production.
export const bch = {
  Address: {
    // Return an object similar to bch-js Address.utxo
    utxo: async (address) => {
      return { utxos: [] };
    }
  }
};

// Simple broadcast helper: if BLOCKBOOK_URL env is set, POST to its /api/v2/sendtx/ or use generic JSON-RPC
// For development, if no external provider is configured, return a fake txid to allow flow testing.
export async function broadcastRawTransaction(rawHex) {
  const blockbook = process.env.BLOCKBOOK_URL;
  if (blockbook) {
    try {
      const url = blockbook.replace(/\/$/, '') + '/api/v2/sendtx/';
      const resp = await fetch(url, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ rawtx: rawHex }) });
      if (!resp.ok) throw new Error('Broadcast failed ' + resp.status);
      const text = await resp.text();
      return text || null;
    } catch (e) {
      throw e;
    }
  }

  // Dev fallback: return synthetic txid
  const fakeTxid = 'tx-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2,8);
  return fakeTxid;
}
