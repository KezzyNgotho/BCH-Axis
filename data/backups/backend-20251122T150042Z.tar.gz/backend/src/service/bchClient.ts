import BCHJS from '@psf/bch-js';

export const bch = new BCHJS({ restURL: 'https://trest.bitcoin.com/v2/' }); // testnet
