import { Router } from 'express';
import { getFees, calculateFee } from '../services/feeService';

const router = Router();

// Get all fees
router.get('/', (req, res) => {
  res.json(getFees());
});

// Calculate fee
router.post('/calculate', (req, res) => {
  const { amount, feeId } = req.body;
  try {
    const value = calculateFee(amount, feeId);
    res.json({ fee: value });
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

export default router;
