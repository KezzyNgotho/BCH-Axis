import { Router } from 'express';
import contractService from '../service/contractService';

const router = Router();

// GET /api/contracts - list all known contracts (from deployment.json or build/)
router.get('/', (req, res) => {
  try {
    const all = contractService.loadContracts();
    res.json(all);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/contracts/:name - get contract detail
router.get('/:name', (req, res) => {
  try {
    const c = contractService.getContract(req.params.name);
    if (!c) return res.status(404).json({ error: 'Contract not found' });
    res.json(c);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

export default router;
