import { bch } from '../config/bchClient.js';
import contractService from './contractService.js';
import crypto from 'crypto';
import db from '../db.js';

export const createVault = async (ownerPublicKey, type = 'single', merchantId = null) => {
  const contractName = type === 'multi' ? 'MultiSigVault' : 'Vault';
  const contracts = contractService.loadContracts();
  const contractInfo = contracts[contractName] || null;
  const id = crypto.randomUUID();
  const name = `Vault-${id.slice(0,6)}`;
  const owners = JSON.stringify([ownerPublicKey]);
  const address = contractInfo ? contractInfo.address : null;
  const privateKey = contractInfo && contractInfo.privateKey ? contractInfo.privateKey : null;
  const now = new Date().toISOString();
  db.prepare('INSERT INTO vaults (id, name, type, owners, contract_name, address, merchant_id, private_key, balance, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)')
    .run(id, name, type, owners, contractName, address, merchantId, privateKey, 0, now);
  return getVault(id);
};

export const listVaults = () => db.prepare('SELECT * FROM vaults ORDER BY created_at DESC').all();

export const getVault = (vaultId) => db.prepare('SELECT * FROM vaults WHERE id = ?').get(vaultId);

export const getVaultUtxos = async (vaultId) => {
  const vault = getVault(vaultId);
  if (!vault) throw new Error('Vault not found');
  if (!vault.address) throw new Error('Vault has no associated on-chain address');
  const utxoRes = await bch.Address.utxo(vault.address);
  return utxoRes && utxoRes.utxos ? utxoRes.utxos : utxoRes;
};

export const getVaultBalance = async (vaultId) => {
  const utxos = await getVaultUtxos(vaultId);
  const sum = (utxos || []).reduce((s, u) => s + (u.satoshis || u.value || 0), 0);
  db.prepare('UPDATE vaults SET balance = ? WHERE id = ?').run(sum, vaultId);
  return sum;
};

// Prepare an unsigned spend payload for client-side signing.
export const prepareVaultSpend = async (vaultId, recipient, amountSats, opts = {}) => {
  const vault = getVault(vaultId);
  if (!vault) throw new Error('Vault not found');
  if (!vault.address) throw new Error('Vault has no on-chain address');

  // Get UTXOs
  const utxos = await getVaultUtxos(vaultId);
  if (!utxos || utxos.length === 0) throw new Error('No UTXOs available for vault');

  // Try to attach artifact/abi to allow client to instantiate Contract
  const contractInfo = contractService.getContract(vault.contractName || 'Vault');
  const artifact = contractInfo ? contractInfo.artifact : null;

  // Suggest using the first UTXO as the active input, but return full list
  const suggestedInputIndex = 0;

  return {
    vault: {
      id: vault.id,
      address: vault.address,
      contractName: vault.contractName,
      balance: vault.balance
    },
    artifact,
    abi: artifact ? artifact.abi : null,
    utxos,
    suggestedInputIndex,
    to: recipient,
    amountSats,
    note: 'This payload is intended for client-side signing. Use CashScript on the client with the provided artifact and utxos to build & sign the spend.'
  };
};

// Prepare spend instructions. If server has privateKey for the vault, return a signed txid after broadcasting.
export const spendVault = async (vaultId, recipient, amountSats) => {
  const vault = getVault(vaultId);
  if (!vault) throw new Error('Vault not found');
  if (!vault.address) throw new Error('Vault has no on-chain address');

  // Get UTXOs
  const utxos = await getVaultUtxos(vaultId);
  const balance = (utxos || []).reduce((s, u) => s + (u.satoshis || u.value || 0), 0);
  if (amountSats > balance) throw new Error('Insufficient balance');

  // Return spending plan (unsigned) so caller can sign; if privateKey is present, we can sign and broadcast.
  const plan = {
    from: vault.address,
    to: recipient,
    amountSats,
    utxos
  };

  if (vault.privateKey) {
    // Server-side signing path - build, sign and broadcast a simple transaction using bch-js
    // Note: we implement a basic bch-js sendTx flow using the wallet private key if available.
    // For safety, we'll rely on bch.RawTransactions.sendRawTransaction only if we can build a raw hex.
    const Wallet = require('@psf/bitcoincashjs-lib');
    // Building a full signed transaction is non-trivial here; return the plan for now.
    // TODO: implement full TX builder+signer using bitcoincashjs-lib or bch-js wallet methods.
    return { plan, note: 'Server has private key but automatic signing not implemented; returning plan.' };
  }

  return { plan, note: 'Unsigned spending plan returned. Sign & broadcast externally.' };
};
