import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';

const DB_PATH = process.env.DB_PATH || path.resolve(process.cwd(), 'data', 'db.sqlite');

// Ensure directory exists
fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });

const db = new Database(DB_PATH);

// Initialize schema if not exists
db.exec(`
CREATE TABLE IF NOT EXISTS merchants (
  id TEXT PRIMARY KEY,
  name TEXT,
  api_key TEXT,
  api_key_hash TEXT,
  revoked INTEGER DEFAULT 0,
  scopes TEXT,
  xpub TEXT,
  next_index INTEGER DEFAULT 0,
  created_at TEXT
);

CREATE TABLE IF NOT EXISTS vaults (
  id TEXT PRIMARY KEY,
  name TEXT,
  type TEXT,
  owners TEXT,
  contract_name TEXT,
  address TEXT,
  merchant_id TEXT,
  private_key TEXT,
  balance INTEGER DEFAULT 0,
  created_at TEXT
);

CREATE TABLE IF NOT EXISTS invoices (
  id TEXT PRIMARY KEY,
  buyer TEXT,
  amount INTEGER,
  currency TEXT,
  vault_id TEXT,
  merchant_id TEXT,
  address TEXT,
  webhook_url TEXT,
  status TEXT,
  txid TEXT,
  created_at TEXT,
  paid_at TEXT
);
`);

// If older DB exists, ensure columns are present (safe to run repeatedly)
try {
  const merchantsCols = db.prepare("PRAGMA table_info('merchants')").all().map(r => r.name);
  if (!merchantsCols.includes('xpub')) db.prepare('ALTER TABLE merchants ADD COLUMN xpub TEXT').run();
  if (!merchantsCols.includes('next_index')) db.prepare('ALTER TABLE merchants ADD COLUMN next_index INTEGER DEFAULT 0').run();
  if (!merchantsCols.includes('api_key_hash')) db.prepare('ALTER TABLE merchants ADD COLUMN api_key_hash TEXT').run();
  if (!merchantsCols.includes('revoked')) db.prepare('ALTER TABLE merchants ADD COLUMN revoked INTEGER DEFAULT 0').run();
  if (!merchantsCols.includes('scopes')) db.prepare('ALTER TABLE merchants ADD COLUMN scopes TEXT').run();
} catch (e) {
  // ignore
}

try {
  const vaultCols = db.prepare("PRAGMA table_info('vaults')").all().map(r => r.name);
  if (!vaultCols.includes('merchant_id')) db.prepare('ALTER TABLE vaults ADD COLUMN merchant_id TEXT').run();
} catch (e) {}

try {
  const invCols = db.prepare("PRAGMA table_info('invoices')").all().map(r => r.name);
  if (!invCols.includes('merchant_id')) db.prepare('ALTER TABLE invoices ADD COLUMN merchant_id TEXT').run();
  if (!invCols.includes('address')) db.prepare('ALTER TABLE invoices ADD COLUMN address TEXT').run();
} catch (e) {}

export default db;
