import db from '../db.js';
import crypto from 'crypto';
import registry from '../service/registry.js';

const API_KEY_SECRET = process.env.API_KEY_SECRET || null;
if (!API_KEY_SECRET) {
  console.warn('Warning: API_KEY_SECRET is not set. Generating ephemeral secret for development. Set API_KEY_SECRET in production.');
}

function hmacKey(key) {
  const secret = API_KEY_SECRET || crypto.createHash('sha256').update('dev-secret').digest('hex');
  return crypto.createHmac('sha256', secret).update(key).digest('hex');
}

export function requireApiKey(req, res, next) {
  const key = req.header('x-api-key');
  if (!key) return res.status(401).json({ error: 'Missing API key' });

  // First, try the in-memory on-chain registry tokens
  const entry = registry.getByToken(key);
  if (entry) {
    req.merchant = {
      id: entry.txid,
      name: entry.name,
      api_key: key,
      xpub: entry.xpub,
      next_index: 0,
      scopes: null
    };
    return next();
  }

  // Fallback: Look up by exact plaintext first (legacy) or by hashed match in DB
  let row = db.prepare('SELECT * FROM merchants WHERE api_key = ?').get(key);
  if (!row) {
    // try hashed comparison
    const hashed = hmacKey(key);
    row = db.prepare('SELECT * FROM merchants WHERE api_key_hash = ?').get(hashed);
  }

  if (!row) return res.status(403).json({ error: 'Invalid API key' });
  if (row.revoked) return res.status(403).json({ error: 'API key revoked' });

  // attach merchant info; for convenience expose the presented api key on req.merchant.api_key
  req.merchant = {
    id: row.id,
    name: row.name,
    api_key: key,
    xpub: row.xpub || null,
    next_index: typeof row.next_index === 'number' ? row.next_index : (row.next_index ? Number(row.next_index) : 0),
    scopes: row.scopes || null
  };
  next();
}
