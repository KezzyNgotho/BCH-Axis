import { Router } from 'express';
import { createEscrow, releaseEscrow, cancelEscrow, listEscrows } from '../services/escrowService';

const router = Router();

router.post('/create', (req, res) => {
  const { buyer, seller, amount } = req.body;
  try {
    const escrow = createEscrow(buyer, seller, amount);
    res.json(escrow);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.post('/release', (req, res) => {
  const { escrowId } = req.body;
  try {
    const escrow = releaseEscrow(escrowId);
    res.json(escrow);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.post('/cancel', (req, res) => {
  const { escrowId } = req.body;
  try {
    const escrow = cancelEscrow(escrowId);
    res.json(escrow);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

router.get('/', (req, res) => {
  res.json(listEscrows());
});

export default router;
