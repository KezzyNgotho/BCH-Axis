import fs from 'fs';
import path from 'path';

const entry = path.resolve('./src/index.js');
(async () => {
  try {
    console.log('Importing', entry);
    await import('file://' + entry);
    console.log('OK', entry);
  } catch (e) {
    console.error('ERROR importing', entry);
    console.error(e && e.stack ? e.stack : e);
    process.exitCode = 1;
  }
})();
