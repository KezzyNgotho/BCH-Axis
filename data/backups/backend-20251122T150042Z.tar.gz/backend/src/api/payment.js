import { Router } from 'express';
import * as paymentService from '../service/paymentService.js';
import { requireApiKey } from '../middleware/auth.js';

const router = Router();

router.post('/create', requireApiKey, (req, res) => {
  const { buyer, amount, currency = 'BCH', vaultId, webhookUrl } = req.body;
  try {
    const merchantId = req.merchant && req.merchant.id ? req.merchant.id : null;
    const invoice = paymentService.createInvoice({ buyer, amount, currency, vaultId, webhookUrl, merchantId });
    res.json(invoice);
  } catch (err) {
    res.status(400).json({ error: err && err.message ? err.message : String(err) });
  }
});

router.post('/pay', async (req, res) => {
  const { invoiceId, txid } = req.body;
  try {
    const inv = await paymentService.markInvoicePaid(invoiceId, txid);
    res.json(inv);
  } catch (err) {
    res.status(400).json({ error: err && err.message ? err.message : String(err) });
  }
});

router.get('/', (req, res) => {
  res.json(paymentService.listInvoices());
});

router.get('/:id', (req, res) => {
  const inv = paymentService.getInvoice(req.params.id);
  if (!inv) return res.status(404).json({ error: 'Invoice not found' });
  res.json(inv);
});

export default router;
