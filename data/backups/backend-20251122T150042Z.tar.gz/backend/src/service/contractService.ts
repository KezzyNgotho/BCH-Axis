import fs from 'fs';
import path from 'path';

type ContractInfo = {
  name: string;
  file?: string;
  address?: string;
  txid?: string;
  artifact?: any;
};

const buildDir = path.resolve(process.cwd(), 'build');
const deploymentPath = path.resolve(process.cwd(), 'deployment.json');

export function loadContracts(): Record<string, ContractInfo> {
  const result: Record<string, ContractInfo> = {};

  // Try to load deployment.json first (contains addresses + artifacts)
  if (fs.existsSync(deploymentPath)) {
    try {
      const d = JSON.parse(fs.readFileSync(deploymentPath, 'utf8'));
      if (d && d.contracts) {
        for (const [k, v] of Object.entries<any>(d.contracts)) {
          result[k] = {
            name: v.name || k,
            file: v.file,
            address: v.address,
            txid: v.txid,
            artifact: v.artifact || null
          };
        }
        // attach private keys if present
        if (d.privateKeys) {
          for (const [k, pk] of Object.entries<any>(d.privateKeys)) {
            if (result[k]) result[k].artifact = result[k].artifact || null; // keep artifact
            // add privateKey property
            if (result[k]) (result[k] as any).privateKey = pk;
          }
        }
        return result;
      }
    } catch (err) {
      // fall through to scanning build dir
    }
  }

  // Fallback: scan build/*.json for artifacts (no addresses)
  if (fs.existsSync(buildDir)) {
    const files = fs.readdirSync(buildDir).filter(f => f.endsWith('.json'));
    for (const f of files) {
      try {
        const artifact = JSON.parse(fs.readFileSync(path.join(buildDir, f), 'utf8'));
        const name = artifact.contractName || path.basename(f, '.json');
        result[name] = { name, file: f, artifact };
      } catch (err) {
        // ignore parse errors
      }
    }
  }

  return result;
}

export function getContract(name: string): ContractInfo | null {
  const all = loadContracts();
  return all[name] || null;
}

export default { loadContracts, getContract };
