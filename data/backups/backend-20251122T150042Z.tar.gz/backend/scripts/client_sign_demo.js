#!/usr/bin/env node
/*
Client-side demo: prepare -> build & sign using CashScript (best-effort).

This script will:
- Read deployment/build artifacts and UTXOs (like the prepare endpoint)
- Attempt to instantiate a CashScript `Contract` and build a transaction for `spend`
- Try a few CashScript client APIs defensively and print what succeeded

Note: CashScript client APIs differ by version. This script attempts several common methods
and falls back to printing an explicit example for you to adapt.

Usage:
  node backend/scripts/client_sign_demo.js [vaultName|'Vault'] [recipient] [amountSats] [privkeyWIF]

If you provide a private key (WIF), the script will attempt to sign locally for demo purposes.

Security: Never put production private keys into files. This demo is for local testing only.
*/

const fs = require('fs');
const path = require('path');

async function preparePayload(vaultName) {
  const deploymentPath = path.resolve(process.cwd(), 'deployment.json');
  const buildDir = path.resolve(process.cwd(), 'build');
  let deployment = null;
  if (fs.existsSync(deploymentPath)) {
    try { deployment = JSON.parse(fs.readFileSync(deploymentPath, 'utf8')); } catch (e) {}
  }
  let entry = null;
  if (deployment && deployment.contracts && deployment.contracts[vaultName]) entry = deployment.contracts[vaultName];
  else {
    const file = path.join(buildDir, `${vaultName}.json`);
    if (fs.existsSync(file)) entry = { name: vaultName, artifact: JSON.parse(fs.readFileSync(file, 'utf8')), address: null };
  }
  if (!entry) throw new Error('Contract artifact not found for ' + vaultName);

  // Try to fetch UTXOs via bch-js if available
  let utxos = [];
  try {
    const BCH = require('@psf/bch-js');
    const bchjs = new BCH({ restURL: process.env.BCH_REST_URL || 'https://trest.bitcoin.com/v2/' });
    if (entry.address) {
      const r = await bchjs.Address.utxo(entry.address);
      utxos = r && r.utxos ? r.utxos : r;
    }
  } catch (err) {
    // ignore network errors
  }

  return { entry, utxos };
}

async function tryCashScriptBuild(artifact, address, utxos, recipient, amountSats, privkeyWIF) {
  try {
    const cs = require('cashscript');
    const { Contract, ElectrumNetworkProvider } = cs;
    const electrumUrl = process.env.ELECTRUM_URL || 'ssl://electrum.blockstream.info:50002';
    let provider;
    try { provider = new ElectrumNetworkProvider(process.env.ELECTRUM_URL || 'https://electrum.example'); } catch (e) { try { provider = new ElectrumNetworkProvider(electrumUrl); } catch (_) { provider = null; } }

    let contract;
    try {
      if (provider && address) contract = new Contract(artifact, address, provider);
      else contract = new Contract(artifact);
    } catch (err) {
      console.warn('CashScript Contract instantiation failed:', err.message || err);
      return { ok: false, reason: 'instantiate-failed', error: err };
    }

    if (!contract.functions || !contract.functions.spend) {
      return { ok: false, reason: 'no-spend-fn' };
    }

    // Try common CashScript client function patterns
    const fn = contract.functions.spend;

    // Pattern 1: fn(amount).toTxBuilder / toTransaction
    try {
      const attempt = fn(amountSats);
      if (typeof attempt.toTransaction === 'function') {
        const tx = await attempt.toTransaction({ utxos, to: recipient, changeAddress: address });
        return { ok: true, method: 'toTransaction', tx };
      }
      if (typeof attempt.toTxBuilder === 'function') {
        const txb = await attempt.toTxBuilder({ utxos, to: recipient, changeAddress: address });
        return { ok: true, method: 'toTxBuilder', tx: txb };
      }
    } catch (err) {
      // continue
    }

    // Pattern 2: attempt.send(options)
    try {
      const attempt = fn(amountSats);
      if (typeof attempt.send === 'function') {
        // send often broadcasts; to avoid broadcasting we pass dryRun or provider-less
        const res = await attempt.send({ broadcast: false });
        return { ok: true, method: 'send', res };
      }
    } catch (err) {
      // continue
    }

    // Pattern 3: fn(amount).toHex / createTransaction
    try {
      const attempt = fn(amountSats);
      if (typeof attempt.createTransaction === 'function') {
        const tx = await attempt.createTransaction({ utxos, to: recipient, changeAddress: address });
        return { ok: true, method: 'createTransaction', tx };
      }
    } catch (err) {
      // continue
    }

    return { ok: false, reason: 'no-known-api' };
  } catch (err) {
    return { ok: false, reason: 'require-failed', error: err };
  }
}

async function main() {
  const args = process.argv.slice(2);
  const vaultName = args[0] || 'Vault';
  const recipient = args[1] || 'bchtest:qqexample...';
  const amountSats = args[2] ? parseInt(args[2], 10) : 10000;
  const privkeyWIF = args[3] || null;

  console.log('Preparing payload for', vaultName, '->', recipient, amountSats);
  const { entry, utxos } = await preparePayload(vaultName);
  console.log('Artifact loaded:', entry.artifact ? entry.artifact.contractName : 'no-artifact');
  console.log('Address:', entry.address);
  console.log('UTXOs:', utxos && utxos.length ? utxos.length : 0);

  // Try CashScript build
  const csRes = await tryCashScriptBuild(entry.artifact, entry.address, utxos, recipient, amountSats, privkeyWIF);
  if (csRes.ok) {
    console.log('CashScript build succeeded with method:', csRes.method);
    console.log('Result:', csRes.tx || csRes.res);
    process.exit(0);
  }

  console.warn('CashScript build did not succeed. Reason:', csRes.reason || csRes.error || 'unknown');
  console.log('\nManual example for client-side signing with CashScript (adapt to your app):\n');
  console.log(`1) On client, install cashscript@${require('../package.json').dependencies.cashscript || '0.12.0'}`);
  console.log('\n2) Example flow (pseudocode):\n');
  console.log(`const { ElectrumNetworkProvider, Contract } = require('cashscript');`);
  console.log(`const provider = new ElectrumNetworkProvider(process.env.ELECTRUM_URL);`);
  console.log(`const contract = new Contract(ARTIFACT_JSON, '${entry.address}', provider);`);
  console.log(`// Then use contract.functions.spend(...) to construct the tx and sign with the owner's private key.`);

  process.exit(0);
}

main().catch(err => { console.error('Fatal:', err); process.exit(1); });
