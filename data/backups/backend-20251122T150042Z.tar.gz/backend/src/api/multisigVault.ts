import { Router } from 'express';
import { createMultiSigVault, listMultiVaults, spendMultiSigVault } from '../services/multisigService';

const router = Router();

// Create multi-sig vault
router.post('/create', (req, res) => {
  const { owners, requiredSignatures } = req.body;
  try {
    const vault = createMultiSigVault(owners, requiredSignatures);
    res.json(vault);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// Spend from multi-sig vault
router.post('/spend', (req, res) => {
  const { vaultId, recipient, amount, signatures } = req.body;
  try {
    const result = spendMultiSigVault(vaultId, recipient, amount, signatures);
    res.json(result);
  } catch (err: any) {
    res.status(400).json({ error: err.message });
  }
});

// List all multi-sig vaults
router.get('/', (req, res) => {
  res.json(listMultiVaults());
});

export default router;
